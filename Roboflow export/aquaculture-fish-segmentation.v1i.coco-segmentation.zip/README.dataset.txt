# aquaculture-fish-segmentation > 2026-08-26 9:18pm
https://universe.roboflow.com/arid-dodul/aquaculture-fish-segmentation

Provided by a Roboflow user
License: CC BY 4.0

